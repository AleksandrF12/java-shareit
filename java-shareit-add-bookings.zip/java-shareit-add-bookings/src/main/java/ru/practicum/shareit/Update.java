package ru.practicum.shareit;

public interface Update {
}
