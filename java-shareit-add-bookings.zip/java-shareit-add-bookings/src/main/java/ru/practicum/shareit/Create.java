package ru.practicum.shareit;

public interface Create {
}
