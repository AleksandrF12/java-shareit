package ru.practicum.shareit.booking.service;

public enum State {
    ALL,
    CURRENT,
    FUTURE,
    WAITING,
    REJECTED,
    PAST
}
